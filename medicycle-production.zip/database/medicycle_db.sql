-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: medicycle_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fa-box-medical',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Personal Protective Equipment','Gloves, face shields, surgical masks, gowns, and head covers','fa-head-side-mask','active','2026-10-08 17:52:11'),(2,'Wound Care & Dressings','Sterile bandages, gauze swabs, adhesive dressings, and crepe rolls','fa-bandage','active','2026-10-08 17:52:11'),(3,'Diagnostic Consumables','Test strips, disposable probe covers, lancets, and specimen containers','fa-vial','active','2026-10-08 17:52:11'),(4,'Sterilization & Antiseptics','Alcohol prep pads, sterile wraps, indicators, and surface prep wipes','fa-pump-medical','active','2026-10-08 17:52:11'),(5,'Non-Drug Administration','Sterile capped syringes, IV cannulas, infusion sets, and tubing','fa-syringe','active','2026-10-08 17:52:11'),(6,'First Aid & Emergency Kits','Unopened trauma dressings, splints, thermal blankets, and triangular bandages','fa-kit-medical','active','2026-10-08 17:52:11'),(7,'Orthopedic & Mobility Aids','Arm slings, cervical collars, crutch pads, and elastic limb supports','fa-crutch','active','2026-10-08 17:52:11');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `delivery_partner_id` int(11) DEFAULT NULL,
  `pickup_location` text NOT NULL,
  `delivery_location` text NOT NULL,
  `pickup_status` enum('Pending','Picked Up') DEFAULT 'Pending',
  `delivery_status` enum('Assigned','Accepted','Picked Up','In Transit','Delivered','Cancelled') DEFAULT 'Assigned',
  `tracking_notes` text DEFAULT NULL,
  `assigned_at` datetime DEFAULT current_timestamp(),
  `accepted_at` datetime DEFAULT NULL,
  `picked_up_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_delivery_request` (`request_id`),
  KEY `idx_delivery_status` (`delivery_status`),
  KEY `idx_delivery_partner` (`delivery_partner_id`),
  CONSTRAINT `fk_delivery_partner` FOREIGN KEY (`delivery_partner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_delivery_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveries`
--

LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
INSERT INTO `deliveries` VALUES (1,1,NULL,'Surat','surat, ahmedabad','Picked Up','Delivered','\n[2026-10-10 14:29:27] Verified via 6-digit/QR handshake code by Prey Goti\n[2026-10-10 15:18:46] Verified via handshake code by City Hospital','2026-10-09 19:00:22',NULL,NULL,'2026-10-10 15:18:46','2026-10-09 13:30:22','2026-10-10 09:48:46');
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_otps`
--

DROP TABLE IF EXISTS `email_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_otps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `otp_type` enum('registration','password_reset') NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` int(11) DEFAULT 0,
  `is_used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_otp_lookup` (`email`,`otp_type`,`is_used`),
  KEY `idx_otp_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_otps`
--

LOCK TABLES `email_otps` WRITE;
/*!40000 ALTER TABLE `email_otps` DISABLE KEYS */;
INSERT INTO `email_otps` VALUES (2,2,'preygoti11@gmail.com','$2y$10$uc2ne0/jSG3zgjQMFneAueGF8HrGvofkR9aDbs5dSGa3cq8EPi46y','registration','2026-10-09 15:33:12',1,1,'2026-10-09 13:23:12'),(3,3,'preygoti.co24d2@scet.ac.in','$2y$10$gWn8X63XZ4PcViU1fw8BROvjMu1L3FfyyduQm5dw/YFYfgNUvnZH2','registration','2026-10-09 15:36:17',1,1,'2026-10-09 13:26:17');
/*!40000 ALTER TABLE `email_otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_metrics`
--

DROP TABLE IF EXISTS `impact_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_metrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `quantity_redistributed` int(11) NOT NULL,
  `estimated_waste_avoided` decimal(10,2) NOT NULL COMMENT 'kg of medical packaging and consumable waste averted',
  `estimated_value_saved` decimal(10,2) NOT NULL COMMENT 'estimated monetary value in INR',
  `organizations_helped` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_impact_request` (`request_id`),
  CONSTRAINT `fk_impact_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_metrics`
--

LOCK TABLES `impact_metrics` WRITE;
/*!40000 ALTER TABLE `impact_metrics` DISABLE KEYS */;
INSERT INTO `impact_metrics` VALUES (3,1,26,3.12,910.00,1,'2026-10-10 08:59:27'),(5,1,26,3.12,910.00,1,'2026-10-10 09:48:46'),(9,10,2,0.24,70.00,1,'2026-10-10 16:38:16');
/*!40000 ALTER TABLE `impact_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_supplies`
--

DROP TABLE IF EXISTS `medical_supplies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_supplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `supply_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `listing_type` enum('regular','surplus','disposal') NOT NULL DEFAULT 'regular',
  `condition_status` enum('New / Unopened','Sterile Sealed','Surplus Stock') NOT NULL,
  `packaging_status` enum('Original Factory Seal','Tamper Evident Packaging','Intact Outer Box') NOT NULL,
  `disposal_reason` varchar(255) DEFAULT NULL,
  `disposal_method` varchar(255) DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `storage_requirements` varchar(150) DEFAULT 'Room Temperature',
  `location` varchar(150) NOT NULL,
  `city` varchar(100) NOT NULL,
  `availability_date` date DEFAULT NULL,
  `minimum_request_quantity` int(11) DEFAULT 1,
  `status` varchar(50) NOT NULL DEFAULT 'Available',
  `priority_score` int(11) DEFAULT 50,
  `priority_level` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `admin_notes` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_supply_supplier` (`supplier_id`),
  KEY `fk_supply_category` (`category_id`),
  KEY `idx_supply_status` (`status`),
  KEY `idx_supply_city` (`city`),
  KEY `idx_supply_expiry` (`expiry_date`),
  KEY `idx_supply_priority` (`priority_score`),
  KEY `idx_supply_listing_type` (`listing_type`),
  CONSTRAINT `fk_supply_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_supply_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_supplies`
--

LOCK TABLES `medical_supplies` WRITE;
/*!40000 ALTER TABLE `medical_supplies` DISABLE KEYS */;
INSERT INTO `medical_supplies` VALUES (2,2,1,'3-Ply Surgical Earloop Face Masks','BFE >= 98% splash resistant surgical masks',474,'Boxes (50 pcs)','disposal','New / Unopened','Original Factory Seal','Expired in inventory','Authorized Bio-Medical Waste Agency (CBMWTF)','2028-10-09','LOT-MSK-4402','Room Temperature','Surat','',NULL,1,'Disposed',70,'High',NULL,NULL,'2026-10-09 13:23:54','2026-10-10 14:19:02'),(19,2,4,'g','x',0,'Boxes (100 pcs)','surplus','Sterile Sealed','Original Factory Seal',NULL,NULL,'2027-04-10','','Standard Room Temperature (15-25°C)','ahmedabad','',NULL,1,'Transferred',70,'High',NULL,NULL,'2026-10-10 15:57:02','2026-10-10 16:38:16');
/*!40000 ALTER TABLE `medical_supplies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notif_user_read` (`user_id`,`is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,2,'Welcome to MediCycle!','Your organization profile (prey) is set up. Verify your email to complete activation.','login.php',0,'2026-10-09 13:23:12'),(2,3,'Welcome to MediCycle!','Your organization profile (goti) is set up. Verify your email to complete activation.','login.php',0,'2026-10-09 13:26:17'),(3,2,'New Requisition Request','goti requested 26 Boxes (50 pcs) of 3-Ply Surgical Earloop Face Masks.','supplier/requests.php',0,'2026-10-09 13:29:28'),(4,3,'Request Approved by Supplier!','Your request for 26 Boxes (50 pcs) of 3-Ply Surgical Earloop Face Masks was approved! 6-Digit Handshake Code: 266896. Transport arranged.','ngo/my-requests.php',0,'2026-10-09 13:30:22'),(5,2,'Handover Completed & Verified!','Consignment #REQ-1 (26 Boxes (50 pcs) of 3-Ply Surgical Earloop Face Masks) physical handover was verified with 6-digit code. Stock successfully transferred.','supplier/history.php',0,'2026-10-10 08:59:27'),(6,3,'Supplies Received & Verified!','Your clinic has successfully received 26 Boxes (50 pcs) of 3-Ply Surgical Earloop Face Masks (Consignment #REQ-1). Verification complete.','ngo/history.php',0,'2026-10-10 08:59:27'),(7,2,'New Requisition Request','goti requested 200 200 of roti.','supplier/requests.php',0,'2026-10-10 09:01:45'),(8,3,'Request Approved by Supplier!','Your request for 200 200 of roti was approved! 6-Digit Handshake Code: 967944. Transport arranged.','ngo/my-requests.php',0,'2026-10-10 09:01:59'),(9,2,'Handover Completed & Verified!','Consignment #REQ-2 (200 200 of roti) physical handover was verified with 6-digit code. Stock successfully transferred.','supplier/history.php',0,'2026-10-10 09:17:22'),(10,3,'Supplies Received & Verified!','Your clinic has successfully received 200 200 of roti (Consignment #REQ-2). Verification complete.','ngo/history.php',0,'2026-10-10 09:17:22'),(11,2,'Handover Completed & Verified!','Consignment #REQ-1 (26 Boxes (50 pcs) of 3-Ply Surgical Earloop Face Masks) delivery was successfully verified with 6-digit handshake code. Stock officially transferred.','supplier/history.php',0,'2026-10-10 09:48:46'),(12,3,'Supplies Received & Delivery Completed!','Your clinic has verified and received 26 Boxes (50 pcs) of 3-Ply Surgical Earloop Face Masks (Consignment #REQ-1). Verification complete.','ngo/history.php',0,'2026-10-10 09:48:46'),(13,2,'New Requisition Request','goti requested 200 200 of ro.','supplier/requests.php',0,'2026-10-10 12:00:36'),(14,3,'Request Approved by Supplier!','Your request for 200 200 of ro was approved! 6-Digit Handshake Code: 227780. Transport arranged.','ngo/my-requests.php',0,'2026-10-10 12:01:34'),(15,2,'Collection Confirmed by Recipient','goti has confirmed physical collection of 200 200 of ro.','supplier/history.php',0,'2026-10-10 12:02:28'),(16,3,'Requisition Cancelled: Item Expired','Safety Alert: The requested supply \'Expired Diagnostic Reagents\' expired and has been segregated to quarantine. Requisition cancelled.','ngo/my-requests.php',0,'2026-10-10 14:14:01'),(18,2,'Handover Completed & Verified!','Consignment #REQ-7 (40 Pairs of Test Surgical Gloves Latex) delivery was successfully verified with 6-digit handshake code. Stock officially transferred.','supplier/history.php',0,'2026-10-10 14:17:08'),(19,3,'Supplies Received & Delivery Completed!','Your clinic has verified and received 40 Pairs of Test Surgical Gloves Latex (Consignment #REQ-7). Verification complete.','ngo/history.php',0,'2026-10-10 14:17:08'),(20,2,'Handover Completed & Verified!','Consignment #REQ-8 (80 Bags of Test Pediatric Saline IV) delivery was successfully verified with 6-digit handshake code. Stock officially transferred.','supplier/history.php',0,'2026-10-10 14:17:08'),(21,3,'Supplies Received & Delivery Completed!','Your clinic has verified and received 80 Bags of Test Pediatric Saline IV (Consignment #REQ-8). Verification complete.','ngo/history.php',0,'2026-10-10 14:17:08'),(22,3,'Requisition Cancelled: Item Expired','Safety Alert: The requested supply \'Expired Diagnostic Reagents\' expired and has been segregated to quarantine. Requisition cancelled.','ngo/my-requests.php',0,'2026-10-10 14:17:08'),(24,2,'New Requisition Request','goti requested 2 Boxes (100 pcs) of g.','supplier/requests.php',0,'2026-10-10 15:59:17'),(25,3,'Request Accepted by Supplier!','Your request for 2 Boxes (100 pcs) of g was accepted. Handover Code: 912971.','ngo/my-requests.php',0,'2026-10-10 16:13:17'),(26,2,'Handover Completed & Verified!','Consignment for 2 Boxes (100 pcs) of g delivery was successfully verified with 6-digit handshake code. Stock officially transferred.','supplier/history.php',0,'2026-10-10 16:38:16'),(27,3,'Supplies Received & Delivery Completed!','Your clinic has verified and received 2 Boxes (100 pcs) of g. Verification complete.','ngo/history.php',0,'2026-10-10 16:38:16');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `organization_name` varchar(150) NOT NULL,
  `organization_type` varchar(100) NOT NULL,
  `license_number` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(20) NOT NULL,
  `verification_status` enum('pending','verified','rejected') DEFAULT 'pending',
  `verification_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_org_user` (`user_id`),
  KEY `idx_org_city` (`city`),
  KEY `idx_org_status` (`verification_status`),
  CONSTRAINT `fk_org_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,2,'prey','Pharmacy Supplier','rhqeorhq','c.g road','ahmedabad','gujarat','1329123','verified',NULL,'2026-10-09 13:23:12','2026-10-09 13:23:12'),(2,3,'goti','Charitable NGO','rhqeorhq','surat','ahmedabad','gujarat','234123','verified',NULL,'2026-10-09 13:26:17','2026-10-09 13:26:17');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supply_id` int(11) DEFAULT NULL,
  `requester_id` int(11) NOT NULL,
  `requested_quantity` int(11) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `urgency` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `preferred_collection_date` date DEFAULT NULL,
  `message` text DEFAULT NULL,
  `smart_match_score` int(11) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Pending',
  `supplier_remarks` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `handover_code` varchar(30) DEFAULT NULL,
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_request_supply` (`supply_id`),
  KEY `fk_request_user` (`requester_id`),
  KEY `idx_request_status` (`status`),
  CONSTRAINT `fk_request_supply` FOREIGN KEY (`supply_id`) REFERENCES `medical_supplies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_request_user` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests`
--

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
INSERT INTO `requests` VALUES (1,2,3,26,'Rural Health Camp','Low','2027-02-01','hello',NULL,'Completed','',NULL,'307307','2026-10-09 13:29:28','2026-10-09 19:00:22','2026-10-10 15:18:46','2026-10-09 13:29:28','2026-10-10 09:48:46'),(10,19,3,2,'Rural Health Camp','Low','2027-04-12','',NULL,'Completed','',NULL,'912971','2026-10-10 15:59:17','2026-10-10 21:43:17','2026-10-10 22:08:16','2026-10-10 15:59:17','2026-10-10 16:38:16');
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requirements`
--

DROP TABLE IF EXISTS `requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `supply_name` varchar(150) NOT NULL,
  `required_quantity` int(11) NOT NULL,
  `unit` varchar(50) NOT NULL DEFAULT 'Units',
  `urgency` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `required_by` date NOT NULL,
  `city` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Active','Fulfilled','Cancelled') DEFAULT 'Active',
  `fulfilled_by_supplier_id` int(11) DEFAULT NULL,
  `handover_code` varchar(30) DEFAULT NULL,
  `fulfilled_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_req_org` (`organization_id`),
  KEY `fk_req_category` (`category_id`),
  KEY `idx_req_status` (`status`),
  KEY `idx_req_urgency` (`urgency`),
  KEY `idx_req_city` (`city`),
  CONSTRAINT `fk_req_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_req_org` FOREIGN KEY (`organization_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requirements`
--

LOCK TABLES `requirements` WRITE;
/*!40000 ALTER TABLE `requirements` DISABLE KEYS */;
/*!40000 ALTER TABLE `requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'platform_name','MediCycle','Application branding name','2026-10-08 17:52:11'),(2,'support_email','support@medicycle.org','Official contact email','2026-10-08 17:52:11'),(3,'waste_factor_kg_per_unit','0.12','Average kg of waste averted per consumable unit','2026-10-08 17:52:11'),(4,'avg_value_inr_per_unit','35.00','Average INR value per unit redistributed','2026-10-08 17:52:11'),(5,'min_shelf_life_days','30','Minimum remaining shelf life for supply approval','2026-10-08 17:52:11');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role` enum('admin','supplier','ngo','delivery') NOT NULL,
  `email_verified` tinyint(1) DEFAULT 1,
  `status` enum('active','inactive','suspended','pending') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_user_role` (`role`),
  KEY `idx_user_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'System Administrator','admin@medicycle.org','$2y$10$57k5GX/AqWPBarlfLNyJyucW1aSbZIVLi8Z8slmguCzZxph9hxh8i','+91 9800000001','admin',1,'active','2026-08-01 03:30:00','2026-10-08 17:52:11'),(2,'Prey Goti','preygoti11@gmail.com','$2y$10$NpQlTc7NRAyQnFaeCsYtpOOMmNNo3Y2Q3/LAfsQUGl8zmg2MSzy6C','+919510114943','supplier',1,'active','2026-10-09 13:23:12','2026-10-09 13:23:26'),(3,'Prey Goti','preygoti.co24d2@scet.ac.in','$2y$10$ttVa1kh3KUwOFxDJUrWFHO.fk49ljy7KODoxBrt6WKt91oGAfAri6','+919510114943','ngo',1,'active','2026-10-09 13:26:17','2026-10-09 13:26:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-10 22:23:10
